//go:build windows

package output

import (
	"errors"
	"fmt"
	"os"
	"strings"
	"sync"
	"syscall"
	"time"
)

// newPipeOutput implements the pipe backend on Windows using a Windows
// named-pipe client path (for example, \\.\pipe\HomePodSpotifyPcm).
// The shared pipeOutput implementation converts float PCM to the configured
// byte format and manages volume/pause state; os.File can write to a named-pipe
// handle returned by os.OpenFile on Windows.
func newPipeOutput(opts *NewOutputOptions) (out *pipeOutput, err error) {
	if opts.OutputPipe == "" {
		return nil, fmt.Errorf("Windows pipe backend requires audio_output_pipe to name a Windows named pipe")
	}
	if !strings.HasPrefix(strings.ToLower(opts.OutputPipe), `\\.\pipe\`) {
		return nil, fmt.Errorf("Windows pipe backend requires a path like \\\\.\\pipe\\Name; got %q", opts.OutputPipe)
	}

	out = &pipeOutput{
		reader:         opts.Reader,
		volume:         opts.InitialVolume,
		err:            make(chan error, 2),
		externalVolume: opts.ExternalVolume,
		volumeUpdate:   opts.VolumeUpdate,
	}
	out.cond = sync.NewCond(&out.lock)

	out.transform, err = newPipeTransform(opts.OutputPipeFormat)
	if err != nil {
		return nil, err
	}

	// On Windows, opening \\.\pipe\Name is a client connection to a named-pipe
	// instance. When wait_for_reader is enabled, wait for the local server (the
	// HomePod Cast process) to create/listen on the pipe. Do not retry arbitrary
	// failures such as invalid paths or access denied; surface those immediately.
	for {
		out.file, err = os.OpenFile(opts.OutputPipe, os.O_WRONLY, 0)
		if err == nil {
			break
		}
		if !opts.OutputPipeWaitForReader || !isWindowsPipeWaitError(err) {
			return nil, fmt.Errorf("failed to open Windows named pipe %q: %w", opts.OutputPipe, err)
		}
		time.Sleep(100 * time.Millisecond)
	}

	go out.outputLoop()
	return out, nil
}

func isWindowsPipeWaitError(err error) bool {
	// Windows error codes: ERROR_FILE_NOT_FOUND=2, ERROR_PIPE_BUSY=231,
	// ERROR_PIPE_NOT_CONNECTED=233. syscall exposes only a subset of these
	// constants on some Go releases, so compare their documented Errno values.
	return errors.Is(err, syscall.Errno(2)) ||
		errors.Is(err, syscall.Errno(231)) ||
		errors.Is(err, syscall.Errno(233))
}


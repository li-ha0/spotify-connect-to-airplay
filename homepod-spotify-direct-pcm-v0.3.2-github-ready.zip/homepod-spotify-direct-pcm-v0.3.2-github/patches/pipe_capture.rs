//! Direct PCM input from go-librespot over a Windows named pipe.
//!
//! Set HOMEPOD_CAST_INPUT=pipe before starting HomePod Cast and configure
//! go-librespot to write 44.1 kHz stereo signed 16-bit little-endian PCM to
//! \\.\pipe\HomePodSpotifyPcm. This module deliberately does not use WASAPI.

use std::sync::{
    atomic::{AtomicBool, Ordering},
    Arc,
};
use std::thread;
use std::time::{Duration, Instant};

use airplay_audio::{LiveFrameSender, LivePcmFrame};

use windows_sys::Win32::Foundation::{CloseHandle, GetLastError, INVALID_HANDLE_VALUE};
use windows_sys::Win32::Storage::FileSystem::{ReadFile, PIPE_ACCESS_INBOUND};
use windows_sys::Win32::System::Pipes::{
    ConnectNamedPipe, CreateNamedPipeW, DisconnectNamedPipe, PIPE_NOWAIT,
    PIPE_READMODE_BYTE, PIPE_REJECT_REMOTE_CLIENTS, PIPE_TYPE_BYTE,
};

const RATE: u32 = 44_100;
const CHANNELS: u8 = 2;
const SAMPLES_PER_CHANNEL_PER_FRAME: usize = 441; // 10 ms at 44.1 kHz
const FRAME_BYTES: usize = SAMPLES_PER_CHANNEL_PER_FRAME * CHANNELS as usize * 2;
const PIPE_PATH: &str = r"\\.\pipe\HomePodSpotifyPcm";

/// Receive little-endian stereo s16 PCM from go-librespot and feed the existing
/// AirPlay live decoder. This replaces WASAPI loopback only when explicitly
/// selected through HOMEPOD_CAST_INPUT=pipe.
pub fn run_capture(sender: LiveFrameSender, stop: Arc<AtomicBool>) -> anyhow::Result<()> {
    let pipe_name: Vec<u16> = PIPE_PATH.encode_utf16().chain(std::iter::once(0)).collect();
    let silence = vec![0i16; SAMPLES_PER_CHANNEL_PER_FRAME * CHANNELS as usize];

    tracing::info!("direct PCM input enabled; waiting on {PIPE_PATH} (44.1 kHz, stereo, s16le)");

    while !stop.load(Ordering::Relaxed) {
        // HomePod Cast is the pipe server; go-librespot opens this path as a writer.
        let pipe = unsafe {
            CreateNamedPipeW(
                pipe_name.as_ptr(),
                PIPE_ACCESS_INBOUND,
                PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_NOWAIT | PIPE_REJECT_REMOTE_CLIENTS,
                1,
                0,
                64 * 1024,
                0,
                std::ptr::null(),
            )
        };
        if pipe == INVALID_HANDLE_VALUE {
            let err = unsafe { GetLastError() };
            return Err(anyhow::anyhow!("CreateNamedPipeW({PIPE_PATH}) failed: Win32 error {err}"));
        }

        let mut connected = false;
        let mut last_silence = Instant::now();
        while !stop.load(Ordering::Relaxed) {
            let ok = unsafe { ConnectNamedPipe(pipe, std::ptr::null_mut()) };
            if ok != 0 {
                connected = true;
                break;
            }
            let err = unsafe { GetLastError() };
            match err {
                535 => { // ERROR_PIPE_CONNECTED: client connected before ConnectNamedPipe.
                    connected = true;
                    break;
                }
                536 => { // ERROR_PIPE_LISTENING: nonblocking pipe has no client yet.
                    // Prime the AirPlay live decoder while we wait for go-librespot.
                    // A 10 ms frame is emitted at most every 10 ms; try_send is
                    // intentionally non-blocking because the decoder may be full.
                    if last_silence.elapsed() >= Duration::from_millis(10) {
                        let _ = sender.try_send(LivePcmFrame {
                            samples: silence.clone(),
                            channels: CHANNELS,
                            sample_rate: RATE,
                        });
                        last_silence = Instant::now();
                    }
                    thread::sleep(Duration::from_millis(2));
                }
                _ => {
                    unsafe { CloseHandle(pipe) };
                    return Err(anyhow::anyhow!("ConnectNamedPipe({PIPE_PATH}) failed: Win32 error {err}"));
                }
            }
        }

        if !connected {
            unsafe { CloseHandle(pipe) };
            break;
        }

        tracing::info!("go-librespot connected to direct PCM pipe");
        let mut pending = Vec::<u8>::with_capacity(FRAME_BYTES * 4);
        let mut read_buffer = [0u8; 16 * 1024];
        let mut last_audio = Instant::now();

        while !stop.load(Ordering::Relaxed) {
            let mut bytes_read = 0u32;
            let ok = unsafe {
                ReadFile(
                    pipe,
                    read_buffer.as_mut_ptr(),
                    read_buffer.len() as u32,
                    &mut bytes_read,
                    std::ptr::null_mut(),
                )
            };

            if ok == 0 {
                let err = unsafe { GetLastError() };
                match err {
                    232 => { // ERROR_NO_DATA: PIPE_NOWAIT has no bytes available.
                        if last_audio.elapsed() >= Duration::from_millis(10) {
                            let _ = sender.try_send(LivePcmFrame {
                                samples: silence.clone(),
                                channels: CHANNELS,
                                sample_rate: RATE,
                            });
                            last_audio = Instant::now();
                        }
                        thread::sleep(Duration::from_millis(2));
                        continue;
                    }
                    109 | 233 => { // ERROR_BROKEN_PIPE / ERROR_PIPE_NOT_CONNECTED
                        tracing::info!("go-librespot disconnected from direct PCM pipe");
                        break;
                    }
                    _ => {
                        tracing::warn!("ReadFile on direct PCM pipe failed: Win32 error {err}; reconnecting");
                        break;
                    }
                }
            }

            if bytes_read == 0 {
                break;
            }
            last_audio = Instant::now();
            pending.extend_from_slice(&read_buffer[..bytes_read as usize]);

            // ReadFile can return arbitrary byte counts. Emit exact 10 ms PCM
            // frames and retain any partial frame for the next read.
            let mut consumed = 0usize;
            while pending.len() - consumed >= FRAME_BYTES {
                let end = consumed + FRAME_BYTES;
                let samples = pending[consumed..end]
                    .chunks_exact(2)
                    .map(|b| i16::from_le_bytes([b[0], b[1]]))
                    .collect::<Vec<_>>();

                // Apply backpressure instead of dropping frames. The previous
                // non-blocking try_send let go-librespot drain/decode a track as
                // fast as the CPU because the pipe reader kept consuming data.
                // A blocking send fills this bounded queue; that eventually blocks
                // the named pipe writer and keeps Spotify progression realtime.
                if !sender.send(LivePcmFrame {
                    samples,
                    channels: CHANNELS,
                    sample_rate: RATE,
                }) {
                    tracing::info!("AirPlay live decoder disconnected; stopping direct PCM input");
                    stop.store(true, Ordering::Relaxed);
                    break;
                }
                consumed = end;
            }
            if consumed > 0 {
                pending.drain(..consumed);
            }
        }

        unsafe {
            let _ = DisconnectNamedPipe(pipe);
            CloseHandle(pipe);
        }

        if stop.load(Ordering::Relaxed) {
            break;
        }
        // Recreate the server for a later go-librespot reconnect.
        thread::sleep(Duration::from_millis(100));
    }

    Ok(())
}

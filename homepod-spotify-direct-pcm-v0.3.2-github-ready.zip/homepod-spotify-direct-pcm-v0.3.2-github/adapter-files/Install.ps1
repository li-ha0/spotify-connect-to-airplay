﻿# HomePod Spotify Connect for Windows — installer/repair
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Bin = Join-Path $Root 'bin'
$ConfigDir = Join-Path $Root 'config'
$Downloads = Join-Path $Root 'downloads'
$Logs = Join-Path $Root 'logs'
$Run = Join-Path $Root 'run'
New-Item -ItemType Directory -Force -Path $Bin,$ConfigDir,$Downloads,$Logs,$Run | Out-Null
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

function Get-Release([string]$Repo,[string]$Tag) {
    $uri = if ($Tag -eq 'latest') { "https://api.github.com/repos/$Repo/releases/latest" } else { "https://api.github.com/repos/$Repo/releases/tags/$Tag" }
    Invoke-RestMethod -Uri $uri -Headers @{ Accept='application/vnd.github+json'; 'User-Agent'='homepod-spotify-connect-windows' }
}
function Download-Asset($Asset,[string]$Destination) {
    Write-Host "Downloading $($Asset.name)..." -ForegroundColor Cyan
    Invoke-WebRequest -Uri $Asset.browser_download_url -OutFile $Destination -Headers @{ 'User-Agent'='homepod-spotify-connect-windows' }
    if (-not (Test-Path $Destination) -or (Get-Item $Destination).Length -lt 1024) { throw "Download looks incomplete: $($Asset.name)" }
    if (($Asset.PSObject.Properties.Name -contains 'digest') -and $Asset.digest -and $Asset.digest -match '^sha256:(.+)$') {
        $actual = (Get-FileHash -LiteralPath $Destination -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne $Matches[1].ToLowerInvariant()) { Remove-Item $Destination -Force; throw "SHA-256 digest mismatch for $($Asset.name)" }
        Write-Host 'SHA-256 digest verified.' -ForegroundColor Green
    }
}
function Copy-GoLibrespotRuntimeDlls([string]$SourceRoot) {
    if (-not (Test-Path -LiteralPath $SourceRoot)) { return }
    $dlls = @(Get-ChildItem -LiteralPath $SourceRoot -Filter '*.dll' -File -Recurse -ErrorAction SilentlyContinue)
    foreach ($dll in $dlls) {
        # Windows finds load-time DLL dependencies most reliably beside the EXE.
        Copy-Item -LiteralPath $dll.FullName -Destination (Join-Path $Bin $dll.Name) -Force
    }
    if ($dlls.Count -gt 0) {
        Write-Host "Copied $($dlls.Count) go-librespot runtime DLL(s) into bin." -ForegroundColor Green
    }
}
function Install-GoLibrespot {
    $exe = Join-Path $Bin 'go-librespot.exe'
    $extract = Join-Path $Downloads 'go-librespot-extracted'
    if (Test-Path $exe) {
        # Repair older installations: previous installers copied the EXE but could
        # discard adjacent DLLs from the upstream archive.
        Copy-GoLibrespotRuntimeDlls $extract
        Write-Host 'Keeping existing go-librespot.exe.' -ForegroundColor Yellow
        return
    }
    $release = Get-Release 'devgianlu/go-librespot' 'v0.10.3'
    $assets = @($release.assets)
    $asset = $assets | Where-Object { $_.name -match '(?i)windows' -and $_.name -match '(?i)(amd64|x86_64|x64)' -and $_.name -match '(?i)(\.zip|\.tar\.gz|\.tgz|\.exe)$' } | Select-Object -First 1
    if (-not $asset) { throw "No Windows x64 asset found in go-librespot v0.10.3. Assets: $(($assets.name) -join ', ')" }
    $download = Join-Path $Downloads $asset.name; Download-Asset $asset $download
    if ($asset.name -match '(?i)\.exe$') { Copy-Item $download $exe -Force }
    else {
        Remove-Item $extract -Recurse -Force -ErrorAction SilentlyContinue
        New-Item -ItemType Directory -Force -Path $extract | Out-Null
        if ($asset.name -match '(?i)\.zip$') { Expand-Archive -LiteralPath $download -DestinationPath $extract -Force }
        else { & tar.exe -xf $download -C $extract; if ($LASTEXITCODE -ne 0) { throw "tar failed for $($asset.name)" } }
        $found = Get-ChildItem $extract -Recurse -File | Where-Object { $_.Name -match '(?i)^go-librespot(?:[_-].*)?\.exe$' } | Select-Object -First 1
        if (-not $found) { throw "No go-librespot executable found inside $($asset.name)." }
        Copy-Item $found.FullName $exe -Force
        Copy-GoLibrespotRuntimeDlls $extract
    }
    Write-Host "Installed go-librespot $($release.tag_name)." -ForegroundColor Green
}
function Install-HomePodCast {
    $exe = Join-Path $Bin 'HomePod-Cast.exe'
    if (Test-Path $exe) { Write-Host 'Keeping existing HomePod-Cast.exe.' -ForegroundColor Yellow; return }
    $release = Get-Release 'iakacer/windows-airplay-homepod' 'latest'
    $asset = @($release.assets) | Where-Object { $_.name -match '(?i)\.exe$' -and $_.name -match '(?i)homepod.*cast|cast.*homepod' } | Select-Object -First 1
    if (-not $asset) { $asset = @($release.assets) | Where-Object { $_.name -match '(?i)\.exe$' } | Select-Object -First 1 }
    if (-not $asset) { throw "No Windows executable found in HomePod Cast release. Assets: $(($release.assets.name) -join ', ')" }
    $download = Join-Path $Downloads $asset.name; Download-Asset $asset $download
    Copy-Item $download $exe -Force
    Write-Host "Installed HomePod Cast release $($release.tag_name)." -ForegroundColor Green
}
function Write-DefaultConfig {
    $settingsPath = Join-Path $Root 'settings.json'
    $settings = @{ device_name='HomePod'; bitrate=320; log_level='info'; homepod_ip='192.168.6.239'; launch_homepod_cast=$true }
    if (Test-Path $settingsPath) { try { $loaded = Get-Content -Raw -LiteralPath $settingsPath | ConvertFrom-Json; foreach ($p in $loaded.PSObject.Properties) { $settings[$p.Name] = $p.Value } } catch {} }
    $name = [string]$settings.device_name
    if ([string]::IsNullOrWhiteSpace($name)) { $name='HomePod' }
    $nameYaml = ConvertTo-Json -InputObject $name -Compress
    $bitrate = [int]$settings.bitrate
    if ($bitrate -notin @(96,160,320)) { $bitrate=320 }
    $level = [string]$settings.log_level
    if ($level -notin @('error','warn','info','debug','trace')) { $level='info' }
    $config = @"
log_level: $level
device_name: $nameYaml
device_type: speaker
bitrate: $bitrate
audio_backend: pipe
audio_output_pipe: '\\.\pipe\HomePodSpotifyPcm'
audio_output_pipe_format: s16le
audio_output_pipe_wait_for_reader: true
zeroconf_enabled: true
zeroconf_backend: builtin
credentials:
  type: zeroconf
  zeroconf:
    persist_credentials: false
initial_volume: 100
volume_steps: 100
external_volume: false
server:
  enabled: true
  address: 127.0.0.1
  port: 3678
"@
    $configPath = Join-Path $ConfigDir 'config.yml'
    if (Test-Path $configPath) { Copy-Item $configPath (Join-Path $Logs ("config-backup-{0}.yml" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))) -Force }
    Set-Content -LiteralPath $configPath -Value $config -Encoding UTF8
    Write-Host "Wrote config for '$name' ($bitrate kbps, log=$level)." -ForegroundColor Green
}
function Add-FirewallRules {
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent(); $principal=New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { Write-Host 'Not elevated: skipped firewall rules. Rerun Install.ps1 as Administrator if Spotify discovery or AirPlay connection is blocked.' -ForegroundColor Yellow; return }
    $rules=@(
      @{Name='HomePod Spotify Connect Windows - go-librespot'; Program=(Join-Path $Bin 'go-librespot.exe')},
      @{Name='HomePod Spotify Connect Windows - HomePod Cast'; Program=(Join-Path $Bin 'HomePod-Cast.exe')}
    )
    foreach($rule in $rules) {
      Get-NetFirewallRule -DisplayName $rule.Name -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
      New-NetFirewallRule -DisplayName $rule.Name -Direction Inbound -Action Allow -Program $rule.Program -Profile Private -Enabled True | Out-Null
    }
    Write-Host 'Added app-specific inbound firewall rules for Private network profiles.' -ForegroundColor Green
    $public = Get-NetConnectionProfile -ErrorAction SilentlyContinue | Where-Object { $_.NetworkCategory -eq 'Public' }
    if ($public) { Write-Host 'Warning: one or more connected networks are marked Public. For a trusted home LAN, change that network profile to Private or the app-specific rules may not apply.' -ForegroundColor Yellow }
}
try {
    Install-GoLibrespot
    Install-HomePodCast
    Write-DefaultConfig
    Add-FirewallRules
    Write-Host ''
    Write-Host 'Install/repair complete. Next run .\HomePodSpotifyConnect.ps1' -ForegroundColor Green
} catch { Write-Error $_; exit 1 }

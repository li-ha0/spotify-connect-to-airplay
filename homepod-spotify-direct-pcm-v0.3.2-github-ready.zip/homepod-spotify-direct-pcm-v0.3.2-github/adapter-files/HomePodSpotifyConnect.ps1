﻿# HomePod Spotify Connect for Windows — lightweight WinForms control panel
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:Bin = Join-Path $script:Root 'bin'
$script:ConfigDir = Join-Path $script:Root 'config'
$script:LogsDir = Join-Path $script:Root 'logs'
$script:RunDir = Join-Path $script:Root 'run'
$script:SettingsPath = Join-Path $script:Root 'settings.json'
$script:StatePath = Join-Path $script:RunDir 'state.json'
$script:SpotifyExe = Join-Path $script:Bin 'go-librespot.exe'
$script:CastExe = Join-Path $script:Bin 'HomePod-Cast.exe'
New-Item -ItemType Directory -Force -Path $script:LogsDir,$script:RunDir,$script:ConfigDir | Out-Null

function Load-Settings {
    $defaults = [ordered]@{ device_name='HomePod'; bitrate=320; log_level='info'; homepod_ip='192.168.6.239'; launch_homepod_cast=$true }
    if (Test-Path $script:SettingsPath) {
        try { $data=Get-Content -Raw -LiteralPath $script:SettingsPath | ConvertFrom-Json; foreach($p in $data.PSObject.Properties) { $defaults[$p.Name]=$p.Value } }
        catch { [System.Windows.Forms.MessageBox]::Show("settings.json 读取失败，将使用默认设置。`r`n$_",'配置提示','OK','Warning') | Out-Null }
    }
    return $defaults
}
function Save-SettingsAndConfig {
    $name = $script:NameBox.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($name)) { throw 'Spotify 设备名称不能为空。' }
    if ($name.Length -gt 60) { throw '设备名称不能超过 60 个字符。' }
    $bitrate = [int]$script:BitrateBox.SelectedItem
    $level = [string]$script:LogLevelBox.SelectedItem
    $settings = [ordered]@{
        device_name=$name; bitrate=$bitrate; log_level=$level;
        homepod_ip=$script:IpBox.Text.Trim(); launch_homepod_cast=$true
    }
    $settings | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $script:SettingsPath -Encoding UTF8
    $escapedName = ConvertTo-Json -InputObject $name -Compress
    $config = @"
log_level: $level
device_name: $escapedName
device_type: speaker
bitrate: $bitrate
audio_backend: pipe
audio_output_pipe: '\\.\pipe\HomePodSpotifyPcm'
audio_output_pipe_format: s16le
audio_output_pipe_wait_for_reader: true
zeroconf_enabled: true
zeroconf_backend: builtin
credentials:
  type: zeroconf
  zeroconf:
    persist_credentials: false
initial_volume: 100
volume_steps: 100
external_volume: false
server:
  enabled: true
  address: 127.0.0.1
  port: 3678
"@
    $configPath=Join-Path $script:ConfigDir 'config.yml'
    if (Test-Path $configPath) { Copy-Item $configPath (Join-Path $script:LogsDir ("config-backup-{0}.yml" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))) -Force }
    Set-Content -LiteralPath $configPath -Value $config -Encoding UTF8
    $script:StatusLabel.Text = "已保存设置：$name / $bitrate kbps。若 Spotify Connect 正在运行，请重启它以应用新配置。"
}
function Load-State {
    if (Test-Path $script:StatePath) { try { return (Get-Content -Raw $script:StatePath | ConvertFrom-Json) } catch {} }
    return [pscustomobject]@{ spotify_pid=0; spotify_exe=''; spotify_owned=$false; spotify_stdout=''; spotify_stderr=''; cast_pid=0; cast_exe=''; cast_owned=$false; started_at='' }
}
function Save-State($State) { $State | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $script:StatePath -Encoding UTF8 }
function Test-ProcessPath([int]$ProcessId,[string]$ExpectedPath) {
    if ($ProcessId -le 0 -or -not (Test-Path $ExpectedPath)) { return $false }
    $p=Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
    if (-not $p) { return $false }
    try { return ([IO.Path]::GetFullPath($p.Path) -ieq [IO.Path]::GetFullPath($ExpectedPath)) } catch { return $false }
}
function Find-ProcessByPath([string]$ExpectedPath) {
    if (-not (Test-Path $ExpectedPath)) { return $null }
    $expected=[IO.Path]::GetFullPath($ExpectedPath)
    foreach($p in (Get-Process -Name ([IO.Path]::GetFileNameWithoutExtension($ExpectedPath)) -ErrorAction SilentlyContinue)) {
        try { if ([IO.Path]::GetFullPath($p.Path) -ieq $expected) { return $p } } catch {}
    }
    return $null
}
function Start-AirPlay {
    if (-not (Test-Path $script:CastExe)) { throw '没有找到 HomePod-Cast.exe。请先点击「安装/修复」。' }
    $state=Load-State
    $existing=Find-ProcessByPath $script:CastExe
    if ($existing) {
        $script:StatusLabel.Text='HomePod Cast 已经在运行。请在系统托盘图标上右键选择 HomePod mini。'
        [System.Windows.Forms.MessageBox]::Show('HomePod Cast 已经在运行。请在系统托盘中右键其图标，选择 HomePod mini；在 Settings 中可将 AirPlay 输出音量设为较高值。','AirPlay 输出','OK','Information') | Out-Null
        return
    }
    # The patched HomePod Cast reads go-librespot PCM from a named pipe instead
    # of capturing the Windows system mix. The child inherits this environment.
    $previousInputMode = $env:HOMEPOD_CAST_INPUT
    $env:HOMEPOD_CAST_INPUT = 'pipe'
    try {
        $p=Start-Process -FilePath $script:CastExe -WorkingDirectory $script:Bin -PassThru
    } finally {
        if ($null -eq $previousInputMode) {
            Remove-Item Env:HOMEPOD_CAST_INPUT -ErrorAction SilentlyContinue
        } else {
            $env:HOMEPOD_CAST_INPUT = $previousInputMode
        }
    }
    $state.cast_pid=$p.Id; $state.cast_exe=$script:CastExe; $state.cast_owned=$true
    Save-State $state
    Start-Sleep -Milliseconds 900
    $script:StatusLabel.Text='HomePod Cast 已启动（Spotify 直通模式）。请先在托盘图标中选择 HomePod，再启动 Spotify Connect。'
    [System.Windows.Forms.MessageBox]::Show("HomePod Cast 已启动（Spotify PCM 直通模式）。`r`n`r`n1. 找到 Windows 系统托盘中的 HomePod Cast 图标。`r`n2. 右键选择你的 HomePod。`r`n3. 在 Settings 里设置 HomePod 音量。`r`n4. 确认选好 HomePod 后，再回到本窗口点击「启动 Spotify Connect」。`r`n`r`n此模式使用独立 PCM 管道，不应捕获 Windows 其他应用声音。",'选择 HomePod','OK','Information') | Out-Null
}
function Start-Spotify {
    if (-not (Test-Path $script:SpotifyExe)) { throw '没有找到 go-librespot.exe。请先点击「安装/修复」。' }
    $state=Load-State
    if ($state.spotify_pid -and (Test-ProcessPath ([int]$state.spotify_pid) $script:SpotifyExe)) {
        $script:StatusLabel.Text='Spotify Connect 已运行。'
        [System.Windows.Forms.MessageBox]::Show('Spotify Connect 已经运行。若刚刚更改了名称或码率，请先停止，再重新启动。','提示','OK','Information') | Out-Null
        return
    }
    $external=Find-ProcessByPath $script:SpotifyExe
    if ($external) { throw "检测到本项目的 go-librespot 已由其他窗口启动（PID $($external.Id)）。请先通过原窗口停止，避免同一配置被多个实例占用。" }
    if (-not (Test-Path (Join-Path $script:ConfigDir 'config.yml'))) { Save-SettingsAndConfig }
    $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
    $out=Join-Path $script:LogsDir "go-librespot-$stamp.log"
    $err=Join-Path $script:LogsDir "go-librespot-$stamp-error.log"
    $spotifyArgs='--config_dir "{0}"' -f $script:ConfigDir
    try {
        $p=Start-Process -FilePath $script:SpotifyExe -ArgumentList $spotifyArgs -WorkingDirectory $script:Bin -RedirectStandardOutput $out -RedirectStandardError $err -WindowStyle Hidden -PassThru -ErrorAction Stop
    } catch {
        throw "无法创建 go-librespot 进程。`r`n程序：$($script:SpotifyExe)`r`n配置目录：$($script:ConfigDir)`r`nWindows 返回：$($_.Exception.Message)`r`n`r`n请确认文件未被安全软件隔离，并尝试在 PowerShell 中直接运行该 EXE。"
    }
    $state.spotify_pid=$p.Id; $state.spotify_exe=$script:SpotifyExe; $state.spotify_owned=$true
    $state.spotify_stdout=$out; $state.spotify_stderr=$err; $state.started_at=(Get-Date).ToString('o')
    Save-State $state

    # Do not report success merely because Start-Process returned a PID.
    Start-Sleep -Milliseconds 1800
    try { $p.Refresh() } catch {}
    if ($p.HasExited) {
        $exitCode=$p.ExitCode
        $stdoutText=''; $stderrText=''
        try { if (Test-Path $out) { $stdoutText=Get-Content -Raw -LiteralPath $out -ErrorAction SilentlyContinue } } catch {}
        try { if (Test-Path $err) { $stderrText=Get-Content -Raw -LiteralPath $err -ErrorAction SilentlyContinue } } catch {}
        $state.spotify_pid=0; $state.spotify_owned=$false; Save-State $state
        $detail="go-librespot 启动后立即退出。ExitCode=$exitCode`r`n日志：$out`r`n错误日志：$err"
        if (-not [string]::IsNullOrWhiteSpace($stdoutText)) { $detail += "`r`n`r`n--- 标准输出 ---`r`n$($stdoutText.Substring([Math]::Max(0,$stdoutText.Length-1800)))" }
        if (-not [string]::IsNullOrWhiteSpace($stderrText)) { $detail += "`r`n`r`n--- 错误输出 ---`r`n$($stderrText.Substring([Math]::Max(0,$stderrText.Length-1800)))" }
        if ([string]::IsNullOrWhiteSpace($stdoutText) -and [string]::IsNullOrWhiteSpace($stderrText)) {
            $detail += "`r`n`r`n两个日志文件都是空的。错误可能发生在应用日志初始化之前（例如 Windows 加载器/运行库错误），GUI 日志无法捕获。请在普通 PowerShell 中直接运行：`r`n& `"$($script:SpotifyExe)`" --config_dir `"$($script:ConfigDir)`"`r`n并查看控制台或 Windows 弹出的错误信息。"
        }
        throw $detail
    }
    $script:StatusLabel.Text="Spotify Connect 已启动（PID $($p.Id)）。在手机 Spotify 的「连接到设备」中选择 '$($script:NameBox.Text.Trim())'。"
}
function Stop-Spotify {
    $state=Load-State
    if ($state.spotify_owned -and $state.spotify_pid -and (Test-ProcessPath ([int]$state.spotify_pid) $script:SpotifyExe)) {
        Stop-Process -Id ([int]$state.spotify_pid) -Force
        $state.spotify_pid=0; $state.spotify_owned=$false; Save-State $state
        $script:StatusLabel.Text='已停止本程序启动的 Spotify Connect。'
    } else {
        $script:StatusLabel.Text='没有发现由本程序启动且仍在运行的 Spotify Connect 进程。'
    }
}
function Stop-OwnedProcesses {
    $state=Load-State
    if ($state.spotify_owned -and $state.spotify_pid -and (Test-ProcessPath ([int]$state.spotify_pid) $script:SpotifyExe)) { Stop-Process -Id ([int]$state.spotify_pid) -Force -ErrorAction SilentlyContinue }
    if ($state.cast_owned -and $state.cast_pid -and (Test-ProcessPath ([int]$state.cast_pid) $script:CastExe)) { Stop-Process -Id ([int]$state.cast_pid) -Force -ErrorAction SilentlyContinue }
    $state.spotify_pid=0; $state.spotify_owned=$false; $state.cast_pid=0; $state.cast_owned=$false; Save-State $state
    $script:StatusLabel.Text='已停止本程序自己启动的组件；其他窗口/手动启动的同名程序不会被终止。'
}
function Run-Diagnostics {
    $state=Load-State
    $report=New-Object System.Collections.Generic.List[string]
    $report.Add('HomePod Spotify Connect for Windows — Diagnostic report')
    $report.Add("Time: $(Get-Date -Format o)")
    $report.Add("OS: $([Environment]::OSVersion.VersionString)")
    $report.Add("Root: $script:Root")
    $report.Add("Spotify device name: $($script:NameBox.Text)")
    $report.Add("HomePod IP entered: $($script:IpBox.Text)")
    $report.Add('')
    $report.Add('--- Adapter IPv4 ---')
    try { Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | ForEach-Object { $report.Add("$($_.InterfaceAlias): $($_.IPAddress) / $($_.PrefixLength)") } } catch { $report.Add("Cannot query addresses: $_") }
    $report.Add('')
    $report.Add('--- Network profiles ---')
    try { Get-NetConnectionProfile | ForEach-Object { $report.Add("$($_.Name): $($_.NetworkCategory) / $($_.IPv4Connectivity)") } } catch { $report.Add("Cannot query profiles: $_") }
    $report.Add('')
    $report.Add('--- Processes ---')
    foreach($pair in @(@('go-librespot',$script:SpotifyExe),@('HomePod-Cast',$script:CastExe))) {
      $p=Find-ProcessByPath $pair[1]
      $report.Add("$($pair[0]): $(if($p){'running PID '+$p.Id}else{'not running'})")
    }
    $report.Add('')
    $report.Add('--- HomePod /info HTTP check ---')
    $ip=$script:IpBox.Text.Trim()
    if ($ip -match '^\d{1,3}(\.\d{1,3}){3}$') {
      try { $r=Invoke-WebRequest -Uri "http://${ip}:7000/info" -TimeoutSec 3 -UseBasicParsing; $report.Add("No custom User-Agent: HTTP $([int]$r.StatusCode), Server=$($r.Headers['Server'])") } catch { if ($_.Exception.Response) { $report.Add("HTTP check returned: $([int]$_.Exception.Response.StatusCode)") } else { $report.Add("Connection failed: $_") } }
    } else { $report.Add('Skipped: enter an IPv4 address in the IP field.') }
    $report.Add('')
    $report.Add('--- Config (redacted: no credentials should be stored here) ---')
    $cfg=Join-Path $script:ConfigDir 'config.yml'
    if (Test-Path $cfg) { Get-Content $cfg | ForEach-Object { $report.Add($_) } } else { $report.Add('config.yml missing') }
    $path=Join-Path $script:LogsDir ("diagnostic-{0}.txt" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
    $report | Set-Content -LiteralPath $path -Encoding UTF8
    Start-Process notepad.exe -ArgumentList ('"{0}"' -f $path)
    $script:StatusLabel.Text="诊断报告已生成：$path"
}
function Refresh-Status {
    $cast=Find-ProcessByPath $script:CastExe
    $sp=Find-ProcessByPath $script:SpotifyExe
    $castText=if($cast){"AirPlay：运行中 (PID $($cast.Id))"}else{'AirPlay：未运行'}
    $spText=if($sp){"Spotify Connect：运行中 (PID $($sp.Id))"}else{'Spotify Connect：未运行'}
    $script:ProcessLabel.Text="$castText    |    $spText"
    $state=Load-State
    $logLines = New-Object System.Collections.Generic.List[string]
    $logFiles = @()
    if ($state.spotify_stdout -and (Test-Path $state.spotify_stdout)) { $logFiles += [string]$state.spotify_stdout }
    if ($state.spotify_stderr -and (Test-Path $state.spotify_stderr)) { $logFiles += [string]$state.spotify_stderr }
    if (-not $logFiles.Count) {
      $latest = Get-ChildItem $script:LogsDir -Filter 'go-librespot*.log' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 2
      if ($latest) { $logFiles = @($latest | ForEach-Object FullName) }
    }
    foreach ($file in $logFiles) {
      try {
        $tail = @(Get-Content -LiteralPath $file -Tail 10 -ErrorAction Stop)
        if ($tail.Count) {
          $logLines.Add("--- $([IO.Path]::GetFileName($file)) ---")
          foreach ($line in $tail) { $logLines.Add([string]$line) }
        }
      } catch {}
    }
    if ($logLines.Count) {
      $script:LogBox.Text = (($logLines | Select-Object -Last 24) -join [Environment]::NewLine)
      $script:LogHint.Text = '日志尾部（标准输出 + 错误输出）'
    }
}

$settings=Load-Settings
$form=New-Object System.Windows.Forms.Form
$form.Text='HomePod Spotify Connect for Windows'
$form.StartPosition='CenterScreen'
$form.Size=New-Object System.Drawing.Size(820,650)
$form.MinimumSize=New-Object System.Drawing.Size(820,650)
$form.Font=New-Object System.Drawing.Font('Segoe UI',9)
$form.FormBorderStyle='Sizable'

$title=New-Object System.Windows.Forms.Label
$title.Text='HomePod Spotify Connect'
$title.Font=New-Object System.Drawing.Font('Segoe UI',16,[System.Drawing.FontStyle]::Bold)
$title.Location=New-Object System.Drawing.Point(18,14); $title.Size=New-Object System.Drawing.Size(520,32)
$form.Controls.Add($title)
$subtitle=New-Object System.Windows.Forms.Label
$subtitle.Text='手机 Spotify Connect → Windows 接收 → HomePod Cast / AirPlay 2 → HomePod mini'
$subtitle.Location=New-Object System.Drawing.Point(20,49); $subtitle.Size=New-Object System.Drawing.Size(760,24)
$form.Controls.Add($subtitle)

$settingsGroup=New-Object System.Windows.Forms.GroupBox
$settingsGroup.Text='Spotify Connect 设置'; $settingsGroup.Location=New-Object System.Drawing.Point(18,78); $settingsGroup.Size=New-Object System.Drawing.Size(770,92)
$form.Controls.Add($settingsGroup)
$lab=New-Object System.Windows.Forms.Label; $lab.Text='设备名称'; $lab.Location=New-Object System.Drawing.Point(14,27); $lab.Size=New-Object System.Drawing.Size(64,22); $settingsGroup.Controls.Add($lab)
$script:NameBox=New-Object System.Windows.Forms.TextBox; $script:NameBox.Location=New-Object System.Drawing.Point(80,24); $script:NameBox.Size=New-Object System.Drawing.Size(180,24); $script:NameBox.Text=[string]$settings.device_name; $settingsGroup.Controls.Add($script:NameBox)
$lab=New-Object System.Windows.Forms.Label; $lab.Text='码率'; $lab.Location=New-Object System.Drawing.Point(278,27); $lab.Size=New-Object System.Drawing.Size(40,22); $settingsGroup.Controls.Add($lab)
$script:BitrateBox=New-Object System.Windows.Forms.ComboBox; $script:BitrateBox.DropDownStyle='DropDownList'; $script:BitrateBox.Items.AddRange(@('96','160','320')); $script:BitrateBox.Location=New-Object System.Drawing.Point(319,24); $script:BitrateBox.Size=New-Object System.Drawing.Size(80,24); $script:BitrateBox.SelectedItem=[string]$settings.bitrate; if($null -eq $script:BitrateBox.SelectedItem){$script:BitrateBox.SelectedItem='320'}; $settingsGroup.Controls.Add($script:BitrateBox)
$lab=New-Object System.Windows.Forms.Label; $lab.Text='日志等级'; $lab.Location=New-Object System.Drawing.Point(414,27); $lab.Size=New-Object System.Drawing.Size(60,22); $settingsGroup.Controls.Add($lab)
$script:LogLevelBox=New-Object System.Windows.Forms.ComboBox; $script:LogLevelBox.DropDownStyle='DropDownList'; $script:LogLevelBox.Items.AddRange(@('error','warn','info','debug','trace')); $script:LogLevelBox.Location=New-Object System.Drawing.Point(478,24); $script:LogLevelBox.Size=New-Object System.Drawing.Size(90,24); $script:LogLevelBox.SelectedItem=[string]$settings.log_level; if($null -eq $script:LogLevelBox.SelectedItem){$script:LogLevelBox.SelectedItem='info'}; $settingsGroup.Controls.Add($script:LogLevelBox)
$script:SaveBtn=New-Object System.Windows.Forms.Button; $script:SaveBtn.Text='保存设置'; $script:SaveBtn.Location=New-Object System.Drawing.Point(595,22); $script:SaveBtn.Size=New-Object System.Drawing.Size(100,28); $script:SaveBtn.Add_Click({ try { $running=Find-ProcessByPath $script:SpotifyExe; if($running){[System.Windows.Forms.MessageBox]::Show('请先停止 Spotify Connect，再保存配置。','配置正在使用','OK','Warning') | Out-Null; return}; Save-SettingsAndConfig; [System.Windows.Forms.MessageBox]::Show($script:StatusLabel.Text,'保存成功','OK','Information') | Out-Null } catch { [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'保存失败','OK','Error') | Out-Null } }); $settingsGroup.Controls.Add($script:SaveBtn)

$script:IpBox=New-Object System.Windows.Forms.TextBox; $script:IpBox.Location=New-Object System.Drawing.Point(135,57); $script:IpBox.Size=New-Object System.Drawing.Size(180,24); $script:IpBox.Text=[string]$settings.homepod_ip; $settingsGroup.Controls.Add($script:IpBox)
$lab=New-Object System.Windows.Forms.Label; $lab.Text='HomePod IP (诊断用)'; $lab.Location=New-Object System.Drawing.Point(14,60); $lab.Size=New-Object System.Drawing.Size(118,24); $lab.AutoSize=$false; $settingsGroup.Controls.Add($lab)

$buttons=New-Object System.Windows.Forms.FlowLayoutPanel; $buttons.Location=New-Object System.Drawing.Point(18,181); $buttons.Size=New-Object System.Drawing.Size(770,84); $buttons.WrapContents=$true; $buttons.AutoScroll=$false; $form.Controls.Add($buttons)
function Add-UiButton([string]$Text,[scriptblock]$Action,[int]$Width=145) { $b=New-Object System.Windows.Forms.Button; $b.Text=$Text; $b.Size=New-Object System.Drawing.Size($Width,34); $b.Margin=New-Object System.Windows.Forms.Padding(0,0,8,8); $b.Add_Click($Action); $buttons.Controls.Add($b); return $b }
Add-UiButton '安装 / 修复' { try { $args='-NoProfile -ExecutionPolicy Bypass -File "{0}"' -f (Join-Path $script:Root 'Install.ps1'); Start-Process powershell.exe -Verb RunAs -ArgumentList $args; $script:StatusLabel.Text='已请求管理员权限运行安装/修复脚本。' } catch { [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'启动安装失败','OK','Error') | Out-Null } } 120 | Out-Null
Add-UiButton '启动 / 选择 HomePod' { try { Start-AirPlay } catch { [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'AirPlay 启动失败','OK','Error') | Out-Null } } 170 | Out-Null
Add-UiButton '启动 Spotify Connect' { try { $existing=Find-ProcessByPath $script:SpotifyExe; if($existing){ Start-Spotify; return }; Save-SettingsAndConfig; Start-Spotify; Refresh-Status } catch { [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Spotify 启动失败','OK','Error') | Out-Null } } 175 | Out-Null
Add-UiButton '停止 Spotify' { try { Stop-Spotify; Refresh-Status } catch { [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'停止失败','OK','Error') | Out-Null } } 115 | Out-Null
Add-UiButton '停止本项目组件' { try { Stop-OwnedProcesses; Refresh-Status } catch { [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'停止失败','OK','Error') | Out-Null } } 155 | Out-Null
Add-UiButton '打开日志目录' { Start-Process explorer.exe -ArgumentList ('"{0}"' -f $script:LogsDir) } 120 | Out-Null
Add-UiButton '生成诊断报告' { try { Run-Diagnostics } catch { [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'诊断失败','OK','Error') | Out-Null } } 120 | Out-Null
Add-UiButton '编辑配置文件' { $cfg=Join-Path $script:ConfigDir 'config.yml'; if(-not(Test-Path $cfg)){Save-SettingsAndConfig}; Start-Process notepad.exe -ArgumentList ('"{0}"' -f $cfg) } 120 | Out-Null

$script:ProcessLabel=New-Object System.Windows.Forms.Label; $script:ProcessLabel.Location=New-Object System.Drawing.Point(20,273); $script:ProcessLabel.Size=New-Object System.Drawing.Size(760,25); $script:ProcessLabel.Font=New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold); $form.Controls.Add($script:ProcessLabel)
$script:StatusLabel=New-Object System.Windows.Forms.Label; $script:StatusLabel.Location=New-Object System.Drawing.Point(20,300); $script:StatusLabel.Size=New-Object System.Drawing.Size(760,42); $script:StatusLabel.Text='先启动 HomePod Cast 并在托盘菜单里选 HomePod，再启动 Spotify Connect。'; $form.Controls.Add($script:StatusLabel)
$script:LogHint=New-Object System.Windows.Forms.Label; $script:LogHint.Text='go-librespot 日志尾部'; $script:LogHint.Location=New-Object System.Drawing.Point(20,346); $script:LogHint.Size=New-Object System.Drawing.Size(400,20); $form.Controls.Add($script:LogHint)
$script:LogBox=New-Object System.Windows.Forms.TextBox; $script:LogBox.Location=New-Object System.Drawing.Point(20,369); $script:LogBox.Size=New-Object System.Drawing.Size(765,220); $script:LogBox.Multiline=$true; $script:LogBox.ReadOnly=$true; $script:LogBox.ScrollBars='Vertical'; $script:LogBox.Font=New-Object System.Drawing.Font('Consolas',8); $script:LogBox.Anchor='Top,Bottom,Left,Right'; $form.Controls.Add($script:LogBox)
$foot=New-Object System.Windows.Forms.Label; $foot.Text='直通模式：Spotify PCM 通过本地命名管道发送到 HomePod Cast，不经过 Windows 系统混音；要求使用本补丁编译的 go-librespot.exe 和 HomePod-Cast.exe。'; $foot.Location=New-Object System.Drawing.Point(20,596); $foot.Size=New-Object System.Drawing.Size(765,30); $form.Controls.Add($foot)

# Timer refreshes status/log without touching or killing externally launched processes.
$timer=New-Object System.Windows.Forms.Timer; $timer.Interval=2000; $timer.Add_Tick({ Refresh-Status }); $timer.Start()
$form.Add_Shown({ Refresh-Status })
$form.Add_FormClosing({ $timer.Stop() })
[void]$form.ShowDialog()

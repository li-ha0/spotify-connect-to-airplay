﻿# Stop only processes whose PID and executable path match the recorded adapter state.
$ErrorActionPreference='Continue'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$statePath=Join-Path $root 'run\state.json'
$spotifyExe=Join-Path $root 'bin\go-librespot.exe'
$castExe=Join-Path $root 'bin\HomePod-Cast.exe'
if(-not(Test-Path $statePath)){Write-Host 'No state file found; nothing will be killed by process name.'; exit 0}
try{$s=Get-Content -Raw $statePath|ConvertFrom-Json}catch{Write-Warning 'State file cannot be read; did not stop any processes.'; exit 1}
function Stop-Owned([int]$pidValue,[string]$expectedPath,[bool]$owned,[string]$label){
  if(-not $owned -or $pidValue -le 0 -or -not(Test-Path $expectedPath)){return}
  $p=Get-Process -Id $pidValue -ErrorAction SilentlyContinue
  if(-not $p){return}
  try{$actual=[IO.Path]::GetFullPath($p.Path);$expected=[IO.Path]::GetFullPath($expectedPath);if($actual -ieq $expected){Stop-Process -Id $pidValue -Force;Write-Host "Stopped $label (PID $pidValue)."}else{Write-Warning "PID $pidValue executable mismatch; left untouched."}}catch{Write-Warning "Could not verify $label; left untouched."}
}
Stop-Owned ([int]$s.spotify_pid) $spotifyExe ([bool]$s.spotify_owned) 'go-librespot'
Stop-Owned ([int]$s.cast_pid) $castExe ([bool]$s.cast_owned) 'HomePod Cast'
$s.spotify_pid=0;$s.spotify_owned=$false;$s.cast_pid=0;$s.cast_owned=$false
$s|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $statePath -Encoding UTF8
Write-Host 'Finished. Only processes recorded as started by this adapter were considered.'

﻿# CLI compatibility launcher. The GUI is the recommended entry point.
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$gui=Join-Path $root 'HomePodSpotifyConnect.ps1'
if(-not(Test-Path $gui)){throw "Missing $gui"}
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $gui
